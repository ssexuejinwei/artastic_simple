-- MySQL dump 10.13  Distrib 8.0.12, for Win64 (x86_64)
--
-- Host: localhost    Database: guoguo
-- ------------------------------------------------------
-- Server version	8.0.12

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
 SET NAMES utf8 ;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `users` (
  `User_ID` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `User_name` varchar(45) NOT NULL,
  `User_password` varchar(45) NOT NULL,
  `User_sex` varchar(10) NOT NULL,
  `User_age` varchar(10) DEFAULT NULL,
  `User_description` varchar(100) DEFAULT NULL,
  `User_software` varchar(45) DEFAULT NULL,
  `User_job` varchar(45) DEFAULT NULL,
  `User_address` varchar(45) DEFAULT NULL,
  `User_mail` varchar(45) NOT NULL,
  `User_phone` varchar(15) DEFAULT NULL,
  `Registertime` datetime NOT NULL,
  `User_icon` varchar(250) DEFAULT NULL,
  `User_state` varchar(15) NOT NULL,
  `User_token` varchar(45) DEFAULT NULL,
  `token_time` datetime DEFAULT NULL,
  `User_salt` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`User_ID`)
) ENGINE=InnoDB AUTO_INCREMENT=1234567893 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1234567890,'ziyi','123654','1','12',NULL,NULL,NULL,NULL,'ziyiziyijun@163.com',NULL,'2019-04-01 00:00:00','/a60613b465f2dd5c6f5848d3feb40ffd.jpg','1',NULL,NULL,NULL),(1234567891,'jack','123456','boy',NULL,'null',NULL,NULL,NULL,'1234@root.com',NULL,'2019-04-01 16:12:56','http://pic-artastic.oss-cn-shanghai.aliyuncs.com/PicArtastic/1234567891/133b88d1-c9e5-4c15-a26a-89c11caa6a84.jpg?Expires=1869472389&OSSAccessKeyId=LTAIE0LLKSsRlKOV&Signature=kFNIBJJlPmqika5KkclOL%2BqV%2F84%3D','1','5927c4c1-b527-430e-874f-3b102b6dc219','2019-04-02 16:12:56',NULL),(1234567892,'Yiyi','123456','girl',NULL,NULL,NULL,NULL,NULL,'yiyi@root.com',NULL,'2019-04-01 17:50:16','/a60613b465f2dd5c6f5848d3feb40ffd.jpg','1','08f81ce4-b59d-483b-8188-46c92c59903d','2019-04-02 17:50:16',NULL);
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2019-04-01 18:02:57
